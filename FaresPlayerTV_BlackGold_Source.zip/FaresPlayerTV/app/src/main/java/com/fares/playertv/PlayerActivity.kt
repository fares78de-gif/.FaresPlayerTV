package com.fares.playertv

import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = PlayerView(this).apply { useController = false }
        setContentView(view)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onStart() {
        super.onStart()
        player = ExoPlayer.Builder(this).build().also {
            view.player = it
            it.addListener(object : Player.Listener {
                override fun onPlayerError(e: PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "Playback error: ${e.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            })
        }
        play(Playlist.index)
    }

    private fun play(i: Int) {
        val l = Playlist.items
        if (l.isEmpty()) return
        val n = (i + l.size) % l.size
        Playlist.index = n
        player?.apply { setMediaItem(MediaItem.fromUri(l[n].url)); prepare(); playWhenReady = true }
        Toast.makeText(this, l[n].name, Toast.LENGTH_SHORT).show()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) when (e.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { play(Playlist.index + 1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { play(Playlist.index - 1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                player?.let { it.playWhenReady = !it.playWhenReady }; return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onStop() {
        super.onStop()
        player?.release(); player = null
    }
}
