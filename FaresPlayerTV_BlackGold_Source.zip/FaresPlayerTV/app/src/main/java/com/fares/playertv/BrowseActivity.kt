package com.fares.playertv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class BrowseActivity : Activity() {
    private lateinit var acc: Account
    private var cats: List<Pair<String?, String>> = emptyList()
    private var allChannels: List<Channel> = emptyList()
    private var showingHidden = false
    private var selectedCategory: String? = null
    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var title: TextView
    private lateinit var empty: TextView
    private lateinit var search: EditText
    private lateinit var btnAll: Button
    private lateinit var btnHidden: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_browse)
        acc = Account(intent.getStringExtra("s")!!, intent.getStringExtra("u")!!, intent.getStringExtra("p")!!)
        title = findViewById(R.id.tvSectionTitle)
        empty = findViewById(R.id.tvEmpty)
        search = findViewById(R.id.etSearch)
        btnAll = findViewById(R.id.btnAll)
        btnHidden = findViewById(R.id.btnHidden)

        channelAdapter = ChannelAdapter(emptyList(), { channel ->
            val visible = displayedChannels()
            Playlist.items = visible
            Playlist.index = visible.indexOfFirst { it.url == channel.url }.coerceAtLeast(0)
            startActivity(Intent(this, PlayerActivity::class.java))
        }, { channel -> toggleHidden(channel) })

        findViewById<RecyclerView>(R.id.rvChannels).apply {
            layoutManager = LinearLayoutManager(this@BrowseActivity)
            adapter = channelAdapter
            setHasFixedSize(true)
        }
        val catAdapter = RowAdapter(listOf("Toutes les chaînes"), { i ->
            selectedCategory = if (i == 0) null else cats[i].first
            showingHidden = false
            updateTabs()
            loadChannels()
        })
        findViewById<RecyclerView>(R.id.rvCats).apply {
            layoutManager = LinearLayoutManager(this@BrowseActivity)
            adapter = catAdapter
        }
        btnAll.setOnClickListener { showingHidden = false; updateTabs(); renderChannels() }
        btnHidden.setOnClickListener { showingHidden = true; updateTabs(); renderChannels() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderChannels() }
            override fun afterTextChanged(s: Editable?) {}
        })

        Thread {
            try {
                val c = listOf<Pair<String?, String>>(null to "Toutes les chaînes") + Xtream.categories(acc)
                runOnUiThread {
                    cats = c
                    catAdapter.items = c.map { it.second }
                    catAdapter.notifyDataSetChanged()
                    loadChannels()
                }
            } catch (e: Exception) { toast("Erreur serveur : ${e.message}") }
        }.start()
        updateTabs()
    }

    private fun loadChannels() {
        Thread {
            try {
                val l = Xtream.channels(acc, selectedCategory)
                runOnUiThread { allChannels = l; renderChannels() }
            } catch (e: Exception) { toast("Erreur : ${e.message}") }
        }.start()
    }

    private fun displayedChannels(): List<Channel> {
        val hidden = Store.hidden(this, acc)
        val source = if (showingHidden) allChannels.filter { it.url in hidden }
                     else allChannels.filter { it.url !in hidden }
        val q = search.text.toString().trim()
        return if (q.isEmpty()) source else source.filter { it.name.contains(q, ignoreCase = true) }
    }

    private fun renderChannels() {
        val list = displayedChannels()
        channelAdapter.items = list
        channelAdapter.hiddenMode = showingHidden
        channelAdapter.notifyDataSetChanged()
        empty.visibility = if (list.isEmpty()) TextView.VISIBLE else TextView.GONE
        empty.text = if (showingHidden) "Aucune chaîne masquée" else "Aucune chaîne trouvée"
        title.text = if (showingHidden) "Chaînes masquées" else "Toutes les chaînes"
    }

    private fun toggleHidden(channel: Channel) {
        val hidden = Store.hidden(this, acc).toMutableSet()
        if (channel.url in hidden) hidden.remove(channel.url) else hidden.add(channel.url)
        Store.saveHidden(this, acc, hidden)
        renderChannels()
    }

    private fun updateTabs() {
        btnAll.isSelected = !showingHidden
        btnHidden.isSelected = showingHidden
        btnAll.setTextColor(if (!showingHidden) 0xFF17130A.toInt() else 0xFFE5C36B.toInt())
        btnHidden.setTextColor(if (showingHidden) 0xFF17130A.toInt() else 0xFFE5C36B.toInt())
        btnAll.setBackgroundResource(if (!showingHidden) R.drawable.gold_button else R.drawable.dark_button)
        btnHidden.setBackgroundResource(if (showingHidden) R.drawable.gold_button else R.drawable.dark_button)
        renderChannels()
    }

    private fun toast(m: String) = runOnUiThread {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }
}
